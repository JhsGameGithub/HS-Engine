#pragma once

class MouseMoving
{
public:
	virtual void MouseUpdate(int pos) = 0;
};
